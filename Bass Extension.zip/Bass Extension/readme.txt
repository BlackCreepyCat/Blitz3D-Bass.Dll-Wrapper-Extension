How to use:
 - Copy bass.dll and userlib\bass.decls into Your userlib directory.
   (for example C:\Programme\Blitz3D\userlib")

 - If You want to use extension "bass_cd" then copy bass_cd\basscd.dll
   and bass_cd\userlib\bass_cd.decls into Your userlib directory.

 - If You want to use extension "bass_fx" then copy bass_fx\bass_fx.dll
   and bass_fx\userlib\bass_fx.decls into Your userlib directory.

 - If You want to use extension "bass_wma" then copy bass_wma\basswma.dll
   and bass_wma\userlib\bass_wma.decls into Your userlib directory.

Informations:
 - examples\Sounds\Paul van Dyk - Connected.mp3 by http://paulvandyk.de/
 - examples\Sounds\TRANQUIL.XM by http://www.modarchive.com/
 - examples\Sounds\Voice.mp3 by http://nuhr.de/
 - examples\Pictures\1 - 10.jpg by http://gal.mvc.ru/

Description:
 - CD-Example.bb           | Can play CD-tracks (without basscd-extension)
                             use up- and downkey to select Your track, and 
                             play it with enter
 - CreateSample-Example.bb | Create a sample into the RAM and play it
 - EncodeWAVE-Example.bb   | Encode any files into a *.wav file
 - FX-Example.bb           | Shows how You can build an equilicer with reverb
                             function. use [Q] and [A] to set a value for 125 Hz
                             use [W] and [S] to set a value for 1 KHz
                             use [E] and [D] to set a value for 8 KHz
                             use [R] and [F] to set a value for reverb
 - GetInfo-Example.bb      | Shows ho to use structures in Blitz.
                             Get any information about Your selected device.
 - Lips-Example.bb         | Syncronisate a smiley with a voice
 - URL-Example.bb          | Play/ripp a URL-Stream and display any information
                             about the server
 - Visual-Music-Example.bb | Syncronisate pictures with a xm music file


 - CD-Drive-Example.bb     | Show any information about your drives(need basscd)
 - DSP-Example.bb          | Use DSP-FLanger effect (need bass_fx)
 - EncodeWMA-Example.bb    | Encode a soundfile to a wma file (need bass_wma)

 - bass.bb                 | Includes all constants of bass.dll and a function to 
                             get stringversion of bass.dll
 - bass_cd.bb              | Includes all constants of basscd.dll
 - bass_fx.bb              | Includes all constants bass_fx.dll and a function to
                             get stringversion of bass-fx.dll
 - bass_wma.bb             | Includes all constants of basswma.dll

 - ID3.bb                  | Includes all ID3v1.1 Generes

Wrapperfunctions:
 - BASS_GetStringVersion$()                 | BASS_GetVersion
 - BASS_GetDeviceCount()                    | BASS_GetDeviceDescription
 - BASS_GetDeviceDescription$(devnum)       | BASS_GetDeviceDescription
 - BASS_StreamGetTagsCount(haandle,tags)    | BASS_StreamGetTags
 - BASS_StreamGetTag$(hHandle,tags,num)     | BASS_StreamGetTags
 - BASS_RecordGetDeviceCount()              | BASS_RecordGetDeviceDescription
 - BASS_RecordGetDeviceDescription$(devnum) | BASS_RecordGetDeviceDescription
 - BASS_RecordGetInputCount()               | BASS_RecordGetInputName
 - BASS_RecordGetInputName$(input)          | BASS_RecordGetInputName 

Bugs:
 - GetInfo-Example.bb any problem with translate a structure to
   Blitz-Bank. The reason: false values are will be displayed.

 - CD-Drive-Example.bb the same problems

 - DSP-Example.bb problems to hand over the flangerparameter

----------------------------------------------------------------
by Oliver Skawronek aka Vertex
----------------------------------------------------------------

BASSex.rar includes:
BASSex
 +bass_cd
  +examples
   -CD-Drive-Example.bb
  +userlib
   -bass_cd.decls
  -bass_cd.bb
  -bass_cd.chm
  -bass_cd.txt
  -basscd.dll
 +bass_fx
  +examples
   -DSP-Example.bb
  +userlib
   -bass_fx.decls
  -bass_fx.bb
  -bass_fx.dll
  -bass_fx.txt
 +bass_wma
  +examples
   -EncodeWMA-Example.bb
  +userlib
   -bass_wma.decls
  -bass_wma.bb
  -bass_wma.chm
  -bass_wma.txt
  -basswma.dll
 +examples
  +Pictures
   -1.jpg
   -10.jpg
   -2.jpg
   -3.jpg
   -4.jpg
   -5.jpg
   -6.jpg
   -7.jpg
   -8.jpg
   -9.jpg
  +Sounds
   -Paul van Dyk - Connected.mp3
   -TRANQUIL.XM
   -Voice.mp3
  -CD-Example.bb
  -CreateSample-Example.bb
  -EncodeWAVE-Example.bb
  -FX-Example.bb
  -GetInfo-Example.bb
  -Lips-Example.bb
  -URL-Example.bb
  -Visual-Music-Example.bb
 +structures
  -structures.htm
  -structures.txt
 +userlib
  -bass.decls
 -bass.bb
 -bass.chm
 -bass.dll
 -ID3.bb
 -readme.txt